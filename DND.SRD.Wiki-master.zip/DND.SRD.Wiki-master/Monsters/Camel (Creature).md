### Camel

*Large beast, unaligned*

**Armor Class** 9

**Hit Points** 15 (2d10+4)

**Speed** 50 ft.

| STR     | DEX    | CON     | INT    | WIS    | CHA    |
|---------|--------|---------|--------|--------|--------|
| 16 (+3) | 8 (-1) | 14 (+2) | 2 (-4) | 8 (-1) | 5 (-3) |

**Senses** passive Perception 9

**Languages** -

**Challenge** 1/8 (25 XP)

###### Actions

***Bite***. *Melee Weapon Attack:* +5 to hit, reach 5 ft., one target. *Hit:* 2 (1d4) bludgeoning damage.