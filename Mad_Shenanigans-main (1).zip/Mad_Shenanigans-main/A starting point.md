# A Starting Point
!!! info inline end "This is a good starting point"
It is a place to hang things that need to be worked on, researched, refined, and to have a general plan for this whole mess.

## Plan:
- 

## Quick Links:
- [[DM Campaign Codex]]
- [[Player Campaign Codex]]
- [[Game Tasks]]
- [[Research Tasks]]
- [[Running ToDo]]
- [[Links]]
- https://help.obsidian.md/Home
