Business idea
https://www.tiktok.com/t/ZT8N6vB88/