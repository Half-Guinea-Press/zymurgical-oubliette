#G
# Game Tasks
- [ ] Develop mtsen location
- [ ] signature character item as a leveling item
- [ ] passive skills
- [ ] [[stealth checks give amount of time before problems start or potential complications later]]
- [ ] Game idea : shock card
- [x] [[leveling health potion]]
- [x] How to use exhaustion rules better [[Exhaustion from 5e SRD]]
- [x] Build a plan for dm bible for campaign [[DM Campaign Codex]]
