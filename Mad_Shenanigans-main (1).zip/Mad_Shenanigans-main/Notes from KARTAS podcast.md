Dangers and obstacles 
Scenario goal
Available choices
Explore consequences 
Rooting interest

Types of scenarios
Dungeon
Mystery
Chain of fights
Survival 
Intrigue 
Drama
Picaresque 
