*[HTML]: Hyper Text Markup Language
*[d4]: Four Sided Die :material-dice-d4-outline:
*[W3C]: World Wide Web Consortium
