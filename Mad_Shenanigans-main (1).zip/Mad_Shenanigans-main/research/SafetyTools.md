#ttrpg #research
# Safety Tools

##What are we talking about? Hard Hats? Safety Goggles? 
Roleplaying Games are about stories that unfold as they are played. 
## Lines And Veils
## Content Warning
## Tone Conversation
## Open Door Policy
## C.A.T.S.
1. Concept: What is the game about? Summary of the setting, characters and the main plot.
2. Aim: What is the goal of the players? To overcome an enemy? Player-versus-player? Play-to-lose?
3. Tone: Which kind of atmosphere do you want to achieve? Creepy, serious, goofy?
4. Subject Matter: Discussing potentially critical topics, ask for your players’ consent.
## X-Card
## Stars And Wishes

- Communication 
- Teamwork 
- Trust
- Consent
- Off limits
- Safety
- Boundaries 
- Reality check/fantasy check
- Triggers

- Role playing is a safe space

