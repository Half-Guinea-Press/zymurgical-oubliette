https://www.atlas-games.com/planegea

Planegea at a Glance
Discover a world of raw action, primordial horror, and mystic awe.

Planegea is a prehistoric fantasy campaign setting, where a dungeon means the curse-painted caves of a cannibal clan. Gone are the safe hearths of taverns and libraries, kingdoms and cathedrals. Planegea is a place of utter wildness, where survival is the only law and it must be carved from the world by force of might and magic.

Nothing is as you expect in Planegea. Elves are shimmering dream-walkers, dwarves are half stone, humans are beast-tamers, halflings are silent stalkers, gnomes are filthy scavengers, and dragonborn are just a heartbeat away from their draconic ancestors.
