https://www.techtarget.com/whatis/definition/technical-debt#:~:text=Technical%20debt%20%2D%2D%20or%20tech,costly%20it%20becomes%20to%20rectify.
What is technical debt?
Technical debt -- or tech debt -- is the implied cost incurred when businesses do not fix problems that will affect them in the future. Accruing technical debt causes existing problems to get worse over time. The longer debt builds up, the more costly it becomes to rectify.
