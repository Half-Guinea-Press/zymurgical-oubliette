#research #norse #deity
"rememberer"

**Mímir** or **Mim** is a figure in [Norse mythology](https://en.m.wikipedia.org/wiki/Norse_mythology "Norse mythology"), renowned for his knowledge and wisdom, who is beheaded during the [Æsir–Vanir War](https://en.m.wikipedia.org/wiki/%C3%86sir%E2%80%93Vanir_War "Æsir–Vanir War"). Afterward, the god [Odin](https://en.m.wikipedia.org/wiki/Odin "Odin")carries around Mímir's head and it recites secret knowledge and counsel to him.
