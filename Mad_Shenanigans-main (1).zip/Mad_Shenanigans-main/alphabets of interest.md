gothic
armenian
caucasian
georgian
glagolitic
