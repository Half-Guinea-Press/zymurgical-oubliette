Good Morning Murnir,

My name is Mad and I am a 45 year old transgender woman. I have been playing TTRPG's since I was a kid. I have played both sides of the table, player and DM. For the last decade or so I have been the forever DM for a campaign with my kids and their friends. And I am looking at getting to be a player character again.

Name: Mad

Age: 45

Character Name: Ansa Khenbish

Her Baba would always say "That girl has always focused on the horizon rather than the trail meeting her feet." But then again Ansa was always a precocious child, getting herself into mischeif and trouble that the children twice her age in the village hadn't even dreamed of doing yet. It wasn't long before she had outgrown her small village. Insisting that she would go with her cousins to become an adventurer, she would go out into the world and see everything that there was to see. It would not take long for the trail beneath her feet to trip her while she was looking at the horizon.

She doesn't speak much of the time between leaving her village and now. Just short comments thrown out without warning or context and even less in the way of explination afterward. Most who travel with her long enough piece together that her troupe had been ambushed and all but slaughered. Those who had survived were yolked and chained, dragged in a grim procession to the closest slavers port. Some were sold for labor, some sold for the sport of the gladiator pits, and some sold to satisfy someone's twisted hopes and dreams. She never bothered actually stating which she got sold for.

It took more than a few "owners" before she was bought by a perfumed fop for their mysterious master. A long storm thrown boat ride, a short cobblestoned carrage ride, and an abrupt meeting with a bucket of cold water, lye soap, and a sadistic maid with a coarse haired long handled brush ended with the depositing of her naked scrubbed raw posterior on the cold marble tile floor of a mansion that took up more land than her entire village. What happened after that is up to some debate. The spattery of things that have come to light were not given with any connection to dates, times, or what happened first, last, or in the middle.

What is certain is that this mysterious master was more interested in using her as something of bait or sacrifice to lure out their hidden godling. But they hadn't expected that their godling would rather have them as sacrifice. Their lavish decadence and debauchery seasoning their black souls better than any suffering she had experienced. She walked out of the burning mansion with a tapestry draped around her and a new voice in her head. A fair trade she thought.

I am not sure what kind of campaign setting or overall style of play/genre for your game. Currently, I have Ansa envisioned as a Warlock/Bard or a Warlock/Rogue. But I can rebuild her however would fit best within the campaign, group, and starting level.

If you still have a seat open and think I would be a good fit please let me know.

My discord username is maddungeoneer

Thank you for this oportunity
Mad
