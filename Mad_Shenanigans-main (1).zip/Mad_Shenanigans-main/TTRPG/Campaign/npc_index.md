#G #NPC
# NPC Index
## Allies
## Enemies
## Neutrals

The Shopkeeper
The Hint Giver
The Onboarding Character
The Side Kick
The Save Game NPC
The Quest Giver
