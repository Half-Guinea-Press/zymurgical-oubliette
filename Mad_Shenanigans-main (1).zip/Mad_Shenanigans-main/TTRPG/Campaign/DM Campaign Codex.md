# The DM Campaign Codex
## Campaign Scene Setter
## Campaign Story: Up To Now
### Sessions
#### Session 0
## Campaign Setting
## Player Characters (PCs)
### Maddox (Ally)
## Non-Player Characters (NPCs) 
![[npc_index]]
## Campaign Mechanics
