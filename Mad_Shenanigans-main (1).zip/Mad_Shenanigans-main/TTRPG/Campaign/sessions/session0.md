Session 0 Notes
