Location Name: Gwynedd
Welsh kingdom