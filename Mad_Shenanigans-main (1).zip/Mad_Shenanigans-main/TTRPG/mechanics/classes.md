#ttrpg #dnd #class #mechanic #research
## Canon DND 5e Classes
- Barbarian
- Bard
- Cleric
- Druid
- Fighter
- Paladin
- Monk
- Ranger
- Rogue
- Sorceror
- Warlock
- Wizard

## Voldos Spire Of Secrets
- Alchemist
- Captain
- Craftsman
- Gunslinger
- Investigator
- Martyr
- Necromancer
- Warden
- War Mage
- Witch
