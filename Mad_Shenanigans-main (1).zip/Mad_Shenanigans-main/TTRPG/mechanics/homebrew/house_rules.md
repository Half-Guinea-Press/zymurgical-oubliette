Provide clear benifit
avoid punitive to player
clear, understandable, and concise to player

## Battle Ready Bonus
If player knows and expresses their action within 5 seconds of it being their turn then they get +1 bonus to roll for any action

Focuses positive reinforcement with carrots and not sticks
Speeds up combat
Heighten awareness from player
