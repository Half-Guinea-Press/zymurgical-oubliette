#ttrpg #dnd #research #race #species
## Canon DND 5e Species
- Dragonborn
- Dwarf
- Elf
- Gnome
- Half-Elf
- Halfling
- Half-Orc
- Human
- Tiefling

## Voldos Spire Of Secrets
- Geppetin
- Mandrake
- Mousefolk
- Spiritfolk
- Near-Human

## Other ideas
- Kore: statue people
- Kenku
- Dire
- Aesir/Vanir
- Jotun
- Asura/Deva
- Oni/Yokai
- Aes Sidhe
- Pooka/Puca
- Cervitaur: deer centaur
- Aerugo: moth
- Gentle/Haunt Hag
- Felis: cat eared
- Dragontouched
- Brownie
- Goblin
- Tibbit
- Vect: Robo-golem
- Lob: big gentle fey with reptile tail
- Bearded Dragon
- Gecko
- Líf and Lífþrasir offspring
- Hugginn and Muninn offspring
- Fenrir offspring
