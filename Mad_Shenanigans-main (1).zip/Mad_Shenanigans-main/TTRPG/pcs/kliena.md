Name: Kliena
Player: Shanti
