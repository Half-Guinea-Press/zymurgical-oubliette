Name: Maddox
Player: Ally
