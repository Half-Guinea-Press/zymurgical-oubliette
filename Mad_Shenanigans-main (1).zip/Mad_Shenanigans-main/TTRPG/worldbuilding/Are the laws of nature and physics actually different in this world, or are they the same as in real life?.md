#worldbuilding 
#### Are the laws of nature and physics actually different in this world, or are they the same as in real life? 
Overall the laws of nature and physics work the same and the real world. The situations where they don't are because of something forcing them to bend, become wobbly, or become ignorable.
