#worldbuilding 
#### How does magic fit in? 
Magic is the ability to adjust reality. This is typically done in one of two ways: changing the rules by which the universe operates or manipulating what side of a boundary between levels of reality certain things or places are. 
