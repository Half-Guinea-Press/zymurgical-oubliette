#worldbuilding 
#### How do magical beasts fit in?
Magical beasts are either a specialized adaptation to an unusually high amount of ambient magic in a given area or biome, or it has came from a different layer of reality that has different rules as to how things operate and thus has evolved completely differently. Many other realmly beasts do not survive long without the environment in which they originate. Those that do are either capable of adjusting or are capable of adjusting their environment.
