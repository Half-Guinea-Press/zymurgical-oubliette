#braindump

Mongols Slavs Norse Greek Carthage Turk/ottoman Austria/hungary german Duathe de danan Saxon Celts China India

The maw

Koschie

Knacks like feats Recipe/blueprint/instruction gives advantage

Ru orthodox monk order practitioner of sanbo

R? Fashion for style picture book

Cataclysmic event when the moon was struck and parts of it fell

OSR Player DM Game Engine Game Mechanics Setting Characters Player Character Non-Player Character Supernumerary Character Flora Fauna Technology Science Magic

Attributes Ability Scores Characteristics Talents Skills Knowledges Luck Sanity Hit Pointsz Magic Points Strength Dexterity Constitution Intelligence(idea) Size Power Apperance Education(Know) Move Build Dodge Interpersonal Academic General Technical Abilities Stability Agility Intelligence Stamina Willpower Reflexes Awareness Strength Perception Void Honor Glory Status Artisan Martial Scholar Social Trade Skills Distinctions Adversities Passions Anxieties Personality Habits Quirks Endurance Composure Focus Vigilance Decrepitude Warping Intelligence Perception Strength Stamina Presence Communication Dexterity Quickness Virtues Flaws Fatigue Brawn Finesse Wits Resolve Panache Strength Dexterity Stamina Charisma Manipulation Appearance Perception Intelligence Wits War Life Wisom Skills Aspects Skills Stunts Stress Consequences Refresh Physical(Combat) Exploration(Discovery) Social(Intrigue) Shenanigans

Humans are endurance predators

Plotting vs what planning

Play in good faith

Improv: every mistake is a gift

Failure flaws and room for growth

Name: Siobhan

Archetypal characters

How does mechanics manifest in narrative story

Who decided that?

A sense of play
Third person narration of charisma check instead of role playing it out. 
Narrative vs mechanics
Session zero. 
How do you know each other
How did you bond 
Asymmetry of level in pc group 
Pulp spy stories 
Scene Template 
Conflict makes good storytelling 
Discord server???
Discord chat bot rules assistant?
No gatekeeping
Name for NPC 
Fossick VERB 1. Rummage; search.  2. Search for gold in abandoned workings.
Rivière | A necklace of gems that increase in size toward a large central stone, typically consisting of more than one string.
# Campaign Design Thoughts
- Premise
- Awesome Scene Setters
- Awesome Macguffins
- Awesome Panoramas
- Awesome Side Quests
- Tonal Cues
- DnD canon etheral and astral realm
- What is the purpose of a city in the world? Narratively?
- Ocean of clues
- Alignment is dumb
- Alignment only for extra planar beings
# Character Design Thoughts
- Active Wants
- Drives
- record character scars: enemy crit damage causes scars
- Customize as a goal through feats and perks
- Customize for flavor
- Give a prompt for character design
# The DM Screen
## Characters
### Player Characters
- Ally
- August
- Elizabeth
- Elsa
- Lane
- Shanti
- Virginia
### Non-Player Characters
## Campaign
## World
[[WorldBuildingQuestions]]
## Mechanics
### Character Mechanics
- species
- Backgrounds
- classes
- Feats
- Equipment
- Spells
### Game Engine Mechanics
- Checks
 | - Advantage/Disadvantage
 | - Modifiers
 | - Take10/Take20
 | - Extended Check
 | - Critical Sucess/Failure
- Narrative Override
- Player Character Scarring
## Human Ethnicities 
- Nordic
- Germanic
- Slavic
- Mongolian 
# Improv Thoughts
The importance of "yes and"
Only the DM does "no but"
# Mimir
"rememberer"
**Mímir** or **Mim** is a figure in [Norse mythology](https://en.m.wikipedia.org/wiki/Norse_mythology "Norse mythology"), renowned for his knowledge and wisdom, who is beheaded during the [Æsir–Vanir War](https://en.m.wikipedia.org/wiki/%C3%86sir%E2%80%93Vanir_War "Æsir–Vanir War"). Afterward, the god [Odin](https://en.m.wikipedia.org/wiki/Odin "Odin")carries around Mímir's head and it recites secret knowledge and counsel to him.
# Moonfall
Cataclysmic event when the moon was struck and parts of it fell
# Campaign World One Pager 
Narrative Overview
## Major Things About The World
-
-
-
-
-
- Firearms 
## Main Driver For The Campaign
What is the main thing the characters are tryin to accomplish?
## Important People And Groups
# Character Creation Guide
## Species
## Ethnicities
## Classes
## Equipment
## Spells
What sorts of characters will have the most fun in the campaign?
What books can the players use to build their characters?
# Safety Tools
##What are we talking about? Hard Hats? Safety Goggles? 
Roleplaying Games are about stories that unfold as they are played. 
## Lines And Veils
## Content Warning
## Tone Conversation
## Open Door Policy
## C.A.T.S.
1. Concept: What is the game about? Summary of the setting, characters and the main plot.
2. Aim: What is the goal of the players? To overcome an enemy? Player-versus-player? Play-to-lose?
3. Tone: Which kind of atmosphere do you want to achieve? Creepy, serious, goofy?
4. Subject Matter: Discussing potentially critical topics, ask for your players’ consent.
## X-Card
## Stars And Wishes
# Character Integration
# House Rules
# Quotes and thoughts
Acting and improv training
Make someone while quickly. Give them a core quickly. 
If the pcs believe they can inact violence on a villain they will
Credible threat or fun opportunity for violence 
Other people are walking through doors when you are not
Have characters that are already in motion
# Safety Tools
##What are we talking about? Hard Hats? Safety Goggles? 
Roleplaying Games are about stories that unfold as they are played. 
## Lines And Veils
## Content Warning
## Tone Conversation
## Open Door Policy
## C.A.T.S.
1. Concept: What is the game about? Summary of the setting, characters and the main plot.
2. Aim: What is the goal of the players? To overcome an enemy? Player-versus-player? Play-to-lose?
3. Tone: Which kind of atmosphere do you want to achieve? Creepy, serious, goofy?
4. Subject Matter: Discussing potentially critical topics, ask for your players’ consent.
## X-Card
## Stars And Wishes
- Communication 
- Teamwork 
- Trust
- Consent
- Off limits
- Safety
- Boundaries 
- Reality check/fantasy check
- Triggers
- Role playing is a safe space
# Seidr
https://en.m.wikipedia.org/wiki/Seiðr
In [Old Norse](https://en.m.wikipedia.org/wiki/Old_Norse "Old Norse"), **_seiðr_** (sometimes anglicized as _seidhr_, _seidh_, _seidr_, _seithr_, _seith_, or _seid_) was a type of [magic](https://en.m.wikipedia.org/wiki/Magic_(paranormal) "Magic (paranormal)") which was practised in [Norse society](https://en.m.wikipedia.org/wiki/Vikings "Vikings") during the [Late Scandinavian Iron Age](https://en.m.wikipedia.org/wiki/Iron_Age_Scandinavia "Iron Age Scandinavia"). The practice of _seiðr_ is believed to be a form of magic which is related to both the telling and the shaping of the future. Connected to the [Old Norse religion](https://en.m.wikipedia.org/wiki/Old_Norse_religion "Old Norse religion"), its origins are largely unknown, and the practice of it gradually declined after the [Christianization of Scandinavia](https://en.m.wikipedia.org/wiki/Christianization_of_Scandinavia "Christianization of Scandinavia"). Accounts of _seiðr_ later made it into sagas and other literary sources, while further evidence of it has been unearthed by [archaeologists](https://en.m.wikipedia.org/wiki/Archaeology "Archaeology"). Various scholars have debated the nature of _seiðr_, some of them have argued that it was [shamanic](https://en.m.wikipedia.org/wiki/Shamanism "Shamanism") in context, involving visionary journeys by its practitioners.

# Classes
## Canon DND 5e Classes
- Barbarian
- Bard
- Cleric
- Druid
- Fighter
- Paladin
- Monk
- Ranger
- Rogue
- Sorceror
- Warlock
- Wizard
## Voldos Spire Of Secrets
- Alchemist
- Captain
- Craftsman
- Gunslinger
- Investigator
- Martyr
- Necromancer
- Warden
- War Mage
- Witch
# Species
## Canon DND 5e Species
- Dragonborn
- Dwarf
- Elf
- Gnome
- Half-Elf
- Halfling
- Half-Orc
- Human
- Tiefling
## Voldos Spire Of Secrets
- Geppetin
- Mandrake
- Mousefolk
- Spiritfolk
- Near-Human
## Other ideas
- Kore: statue people
- Kenku
- Dire
- Aesir/Vanir
- Jotun
- Asura/Deva
- Oni/Yokai
- Aes Sidhe
- Pooka/Puca
- Cervitaur: deer centaur
- Aerugo: moth
- Gentle/Haunt Hag
- Felis: cat eared
- Dragontouched
- Brownie
- Goblin
- Tibbit
- Vect: Robo-golem
- Lob: big gentle fey with reptile tail
- Bearded Dragon
- Gecko
- Líf and Lífþrasir offspring
- Hugginn and Muninn offspring
- Fenrir offspring
## NPCs
- The Haberdasher
- The Deadman
- The Hierarch
# Powers and dominions
## Powers
- The Cloud Gatherer
- The Wave Maker
- The Unseen
## Dominions
- The throne of Olympus
- The jailer of Tartarus
- The throne of the sea
## Artifacts
- The Scepter of Jove
- The Bident
- The Trident
- The Helm of Hades
# Session Zero
!!! question inline end "Why is this Session Zero and not session one?"
    Well thanks for asking. This is session zero because this is the session before the campaign officially starts. It is the session where we make sure everyone has their character mostly figured out and built. It is the session where I, the narrator, make sure that you, the player, not only knows about the world that we are going to play in but actually knows enough to feel comfortable in the world we are going to play in. This is also where we set ground rules, talk about homebrew rules and mechanics, and where we talk about safety tools. 
## Welcome Everyone To Session Zero!
I know for some of you this will be the first time playing D&D or maybe even your first time playing any table top roleplaying game (TTRPG). I don't want that to be scary. I know that there are a bunch of books with a bunch of rules and descriptions and stat blocks and abbreviations that make no sense. For a lot of people that looks like too much to handle so they never get into it. But you don't have to worry about that. There are only three things that you absolutely need to be able to do to play this game. Everything else you can pick up and figure out along the way. And I will be right there helping and making sure it all works. 
??? success "Have Fun"
    This is a game. And that means that if you aren't having fun then something is wrong. I am not going to tell you that your character is going to win everytime or suceed in everything. To be honest, a character in any story that always gets what they want the first time they try are really boring and no fun. I will tell you that when you suceed it is going to be awesome. And when you fail it is going to help make the story more interesting. This game is all about being a character in a story and pushing the story forward by doing things, messing things up, fixing things, failing, and winning. It needs all of that to make the story not only good but fun to experience. 
??? success "Help Others Have Fun"
    This is a story. It is a story about a group of people that have come together to do something. They are a team. That doesn't mean your character has to be super friends with every other character. But it does mean that you need to be a team that works together. And more importantly it means that you as a player should help the other players have fun too. Give people the oppurtunity to have their moment of awesome in the story. Don't do stuff that is going to make the game not fun for another player. 
??? success "Play Your Character"
    Don't worry about your character sheet or what all the numbers and stuff means. Get into the head of your character and have fun exploring this new world through their eyes. You don't have to have everything figured out about your character either. As you play, your character will grow and fill out details naturally. And that is a good thing. Remember, if after the first couple of sessions what is on your character sheet isn't fitting how you are playing your character the only thing that matters is this: Are you enjoying playing your character? If the answer is yes then I will help you figure out how to make your character sheet fit your character. Don't worry about trying to fit your character to your character sheet. That way isn't normally a fun way to do it anyway. 
## But How Do We Play This Game?

Acting and improv training

Make someone while quickly. Give them a core quickly.

If the pcs believe they can inact violence on a villain they will

Credible threat or fun opportunity for violence

Other people are walking through doors when you are not

Have characters that are already in motion


Main
	Campaign
		Game Session Layout
			Campaign Story #:
				Story Act 1:
					Chapter 1:
						Session 1:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 2:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 3:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Chapter 2:
						Session 4:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 5:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 6:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Chapter 3:
						Session 7:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 8:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 9:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
				Story Act 2:
					Chapter 4:
						Session 10:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 11:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 12:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Chapter 5:
						Session 13:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 14:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 15:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Chapter 6:
						Session 16:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 17:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 18:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
				Story Act 3:
					Chapter 7:
						Session 19:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 20:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 21:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Chapter 8:
						Session 22:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 23:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 24:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Chapter 9:
						Session 25:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 26:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
						Session 27:
							Scene 1:
							Scene 2:
							Scene 3:
							Main Encounter:
							Secondary Encounter:
							Break:
					Denouement
		MCBUYS Outline
			Act 1 Orphan
				Thematic Argument in Action
					I don’t get no respect
						Plot point 1 meet hero/stakes character/villain
						Plot point 2 see hero's flaw in relation to the stakes character
						Plot point 3 meet villain or amplify what we know about villain
					Do you know what your trouble is
						Plot point 4 deflector slows hero or pulls them off the path
						Plot point 5 inciting incident, hero becomes emotionally involved
					Calls and busy signals
						Plot point 6 statement of hero's goal as it relates to stakes character or love interest, hero's problem is made clear to reader
						Plot point 7 a true or unintentional ally forces hero out of comfort zone
						Plot point 8 Hero is ready to move forward towards goal and/or stakes character but just can’t do it
						Plot point 9 Villain or Deflector conflict stops hero or threatens the emotional stakes
					Through the looking glass
						Plot point 10 Depth of feeling between hero and the stakes character or severity of the treat to the victims becomes evident
						Plot point 11 The deflector or Antagonist threatens to take stakes character from hero. Hero may or may not know it is happening
						Plot point 12 Hero decides he must act to save the stakes character
				Inciting Incident
			Act 2 Wanderer
				Thematic Question In Action
					Kick the dog
						Yes 1
						No 1
						Yes 2
						No 2
						Yes 3
						No 3
					Which way is up
						Yes 4
						No 4
						Yes 5
						No 5
					When life gives you lemon
						Yes 6
						No 6
						Yes 7
						No 7
			Act 2.5 Warrior
				Thematic Question vs. Thematic Action
					Make lemonade
						Yes 8
						No 8
						Yes 9
						No 9
						Yes 10
						No 10
					Inside the whale
						Yes 11
						No 11
						Yes 12
						No 12
					Death and rebirth
						Yes 13(Third act solution)
						No 13
						Yes 14
						No 14
			Act 3 Martyr
				Thematic Synthesis
					What’s the worst that can happen?
						Big Yes
						No
					Good guy versus bad guy over stakes
						Big No
						Final Yes
				Denouement
			Players
			Plotline
				Prime Antagonist
			Of Note
				Characters Of Note
					Player Characters
					Non-Player Characters
				Locations Of Note
				Things Of Note
				History Of Note
			Worldbuild
			A Scene Includes
				Location
					Locational Scope
					Location Purpose in Story
				5 Senses
					Sight
					Smell
					Sound
					Tactile
					Taste
				Character's Perspective
					Character's Self-Generated Context
					PC Skills
						Passive Perception
						Active Perception
						Other Passive
						Other Active
				A good scene...
					jas a specific purpose
					provides good information
					offers a point of view
					enhances character development
					contributes to worldbuilding
					shows without telling
					has a distinct beginning, middle, and end
					is like a story in miniature
				Goal
					Desired Endstate
				Asks A Question
				possible fail states
				Criteria for success? 
				What constitutes success state?
		Orphanage campaign
			Campaign skeleton
				Introduction
			Campaign scene
			Player primer
				Environment setup
					StoryData passage
					Style sheet passage
					Header passage setup
					Footer passage setup
				Starting passage
			Character creator
				Background
					Race
					Station/class
				Basics
					Name
					Concept
					Brief description
						Word cloud
						Key word finder
						Symbol cloud
			World build
				Life
					Flora
					Fauna
					Biomes
				Realms
					Dream
					Ever changing Labyrinth
					Unending wyld
					Deep void
				Magic/technology
					Magic
					Technology
				Civilization
					Cultures
					Ethnicities
					Governements
				History
				Land masses
				Bodies of water
					Oceans
					Seas
					Rivers
						Tributaries
				Deity level
					Powers
					Dominions
					Primordial
			Mechanics build
				Races
				Classes
				Skills
				Feats
				Equipment
				Tech
				Magic
			Campaign plot
			Backstory
				Childhood
					Where were you born?
						Was there anything special or important about the day you were born?
					Who were your parents?
						Are they still alive?
							Father?
							Mother?
						What did your parents do for work?
							How well off financially was your family?
					Did you have any siblings?
						Yes
							How many siblings did you have?
								Brothers?
								Sisters?
								Birth order?
								Did you get along with them?
									Did you like your siblings?
						No
						I had cousins that I was raised with that were practically siblings
						I had a crew of other children that I was raised with that were practically siblings
					Who primarily raised you?
						Was is a happy childhood?
						Where did you live during your childhood?
					What sort of games did you play?
						What was our favorite?
					Were there other children who you interacted with?
					Did you have family who lived close to you?
						Did you know them?
					Did you know what you wanted to be when you grew up?
					Did anything unusual or weird happen when you were a child?
				Adolescence
					Where did you live during your adolescence?
					Did you go to school?
						What was your favorite subject?
					Did you apprentice in a craft?
						Did you enjoy it?
						We’re you good at it?
						Did you go off to live with the your Craft Master?
					Did you learn to be a laborer?
					Did you learn the family business?
					Did you interact with kids your age?
						Did you have any friends?
							Who was your best friend?
					What did your siblings do?
					Are your parents alive through your adolescence?
				Young adulthood
				Recent
			Background
				Originally from
					Starting city
					Somewhere else
				Desire to adventure
				Hidden talent
					Arcane
					Nature
					Skill
					Sense
					Companion
					Item
					Supernatural
				Economic status
					Slave
					Poverty
					Poor
					Middle
					High
					Gentry
					Noble
				Guardian/keeper
					Relative
					Appointed
					Hired
				Childhood mentor/patron
					Relative
					Teacher
					Craftsman
					Neighbor
					Elder/wise person
					Affluent eccentric
				Something everyone notices
					Appearance
						Clothes
						Head
							Face
							Hair
						Upper body
							Torso
							Arms
							Hands
						Lower body
							Legs
							Feet
							Hips
					Mannerism
						Accent
						Phrase
						Ticks
						Movement
				Parents
					Both parents
					One parents
					Neither parents
					Step-parent
				Siblings
					0
					1
					2
					3-4
					More
					Birth order
						Oldest
						Youngest
						Middle
				Upbringing
				Training
					Arts
					Sciences
					Engineering
					Religion
					Craft
					Criminal
					Social
				Bonds
				Flaws
				Ideals
				Personalities
				Race
					Subrace
				Class
					Scholar
						Clerical
							Paladin
							Martyr
						Sciences
							Chemist
								Alchemist
								Apothecary
								Herbalist
						Arcane
							Wizard
							War mage
						Forbidden
							Pacts
								Warlock
								Witch
					Engineer
						Craftsman
					Laborer
						Sailor
					Soldier
						Fighter
						Scout
					Frontiersman
						Hunter
						Beastheart
						Sorcerer
				Questions
					Tell me about your childhood
					Tell me about your adventures
				Locations
					Of infancy
					Of childhood
					Of adolescence
					Of young adulthood
					Starting location
				Ethnicity
					Most common
					Common
					Unusual
					Rare
					Unique
				Education
					Formal
						School
						Clerical
					Apprenticeship
					Laborer
					Self taught
		163 Tarot
			Nil
			Fool
			Primordinal
				Primordinal 1
					Cacophony
				Primordinal 2
					Harmony
			Unknown
				Unknown 1
					Hidden
				Unknown 2
					Lost
				Unknown 3
					Forbidden
			Ordinal
				Ordinal 1
					Tree
				Ordinal 2
					Arch
				Ordinal 3
					World
				Ordinal 4
					Wheel
				Ordinal 5
					Grave
			Taboo
				Taboo 1
					Note
				Taboo 2
					Symbol
				Taboo 3
					Melody
				Taboo 4
					Word
				Taboo 5
					Song
				Taboo 6
					Story
				Taboo 7
					Epic
			Upper
				Upper 1
					Mountain
				Upper 2
					Ocean
				Upper 3
					Wind
				Upper 4
					Traveler
				Upper 5
					Keeper
				Upper 6
					Hunter
				Upper 7
					Dome of the Sky
				Upper 8
					Moon
				Upper 9
					Sun
				Upper 10
					Dreamer
				Upper 11
					Weaver
			Lower
				Lower 1
					The Tactician
						Benedict
							orange, yellow, brown
							Master Tactician
				Lower 2
					The Betrayers
						Osric and Finndo
							Osric(Dead)
								silver, red
							Finndo(Dead)
								green, gold
							attempted to overthrow their father and were sent to a war and never returned
				Lower 3
					The Bastard Son
						Eric
							black, red
							Arrogant but Capable
							Greatest Swordsman
							Illegitimate 
				Lower 4
					The Muse
						Deidre
							silver, black
							Most Loved
							Beauty and Compassion
				Lower 5
					The Sorceress
						Fiona
							green, lavender, purple
							Sorceress
							deft mind and stunning beauty
				Lower 6
					The Warlock
						Brand
							green
							manic depressive
							meglomaniac sorceror
							faustian
				Lower 7
					The Vigil
						Llewella
							green, lavender, gray
							sad existence in self exile
				Lower 8
					The Sailor
						Caine
							black, green
							calculating, realist, manipulator
							naval talent and lifestyle
				Lower 9
					The Pirate
						Blyes
							red, orange
							Sorceror
							Extrovert, dashing, charming
				Lower 10
					The Woodsman
						Julian
							white, black
							cold, sinister hunter
				Lower 11
					The Giant
						Gerard
							blue, gray
							strongest man
							loyal but not smart
				Lower 12
					The Rake
						Random
							orange, red, brown
							sneaky rascal
							punk
				Lower 13
					The Twins
						Delwin and Sand
							Delwin
								brown, black
							Sand
								pale tan, dark brown
			Leaf
				Leaf 1
					Acorn
				Leaf 2
					Flower
				Leaf 3
					Poison Ivy
				Leaf 4
					Clover
				Leaf 5
					Maple
				Leaf 6
					Blackthorne
				Leaf 7
					Elm
				Leaf 8
				Leaf 9
					Elder
				Leaf 10
					Alder
				Leaf 11
					Rowan
				Leaf 12
					Ash
				Leaf 13
					Hazel
				Leaf 14
					Yew
				Leaf 15
				Leaf 16
				Leaf 17
					Oak
			Key
				Door 1
				Door 2
				Door 3
				Door 4
				Door 5
				Door 6
				Door 7
				Door 8
				Door 9
				Door 10
				Door 11
				Door 12
				Door 13
				Door 14
				Door 15
				Door 16
				Door 17
				Door 18
				Door 19
			Path
				Path 1
					Path's Head
				Path 2
					Fork in the Road
				Path 3
				Path 4
					Cross roads
				Path 5
				Path 6
					Low Road
				Path 7
					High Road
				Path 8
				Path 9
				Path 10
				Path 11
				Path 12
				Path 13
				Path 14
				Path 15
				Path 16
				Path 17
				Path 18
				Path 19
				Path 20
				Path 21
				Path 22
				Path 23
			Hammer
				Tooth 1
					Nail
				Tooth 2
				Tooth 3
				Tooth 4
				Tooth 5
				Tooth 6
				Tooth 7
				Tooth 8
				Tooth 9
				Tooth 10
				Tooth 11
				Tooth 12
				Tooth 13
				Tooth 14
				Tooth 15
				Tooth 16
				Tooth 17
				Tooth 18
				Tooth 19
				Tooth 20
				Tooth 21
				Tooth 22
				Tooth 23
				Tooth 24
				Tooth 25
				Tooth 26
				Tooth 27
				Tooth 28
				Tooth 29
			Bone
				Bone 1
					Skull
				Bone 2
					Forearm
				Bone 3
					Finger
				Bone 4
					Wisdom Teeth
				Bone 5
					Hand
				Bone 6
				Bone 7
				Bone 8
				Bone 9
				Bone 10
				Bone 11
				Bone 12
				Bone 13
				Bone 14
				Bone 15
				Bone 16
					Bottom Jaw with 16 teeth
				Bone 17
				Bone 18
				Bone 19
				Bone 20
				Bone 21
				Bone 22
				Bone 23
				Bone 24
					Rib cage
				Bone 25
				Bone 26
				Bone 27
				Bone 28
				Bone 29
				Bone 30
				Bone 31
			Blank
		Ideas
			personalities
				Architect
					INTJ-A / INTJ-T
						Imaginative and strategic thinkers, with a plan for everything.
				Logician
					INTP-A / INTP-T
						Innovative inventors with an unquenchable thirst for knowledge.
				Campaigner
					ENFP-A / ENFP-T
						Enthusiastic, creative and sociable free spirits, who can always find a reason to smile.
				Entrepreneur
					ESTP-A / ESTP-T
						Smart, energetic and very perceptive people, who truly enjoy living on the edge.
				Entertainer
					ESFP-A / ESFP-T
						Spontaneous, energetic and enthusiastic people – life is never boring around them.
				Protagonist
					ENFJ-A / ENFJ-T
						Charismatic and inspiring leaders, able to mesmerize their listeners.
				Consul
					ESFJ-A / ESFJ-T
						Extraordinarily caring, social and popular people, always eager to help.
				ISFP-A / ISFP-T
					Flexible and charming artists, always ready to explore and experience something new.
				Logistician
					ISTJ-A / ISTJ-T
						Practical and fact-minded individuals, whose reliability cannot be doubted.
				Virtuoso
					ISTP-A / ISTP-T
						Bold and practical experimenters, masters of all kinds of tools.
				Commander
					ENTJ-A / ENTJ-T
						Bold, imaginative and strong-willed leaders, always finding a way – or making one.
				Executive
					ESTJ-A / ESTJ-T
						Excellent administrators, unsurpassed at managing things – or people.
				Mediator
					INFP-A / INFP-T
						Poetic, kind and altruistic people, always eager to help a good cause.
				Advocate
					INFJ-A / INFJ-T
						Quiet and mystical, yet very inspiring and tireless idealists.
				ISFJ-A / ISFJ-T
					Very dedicated and warm protectors, always ready to defend their loved ones.
				ENTP-A / ENTP-T
					Smart and curious thinkers who cannot resist an intellectual challenge.
			Ideas
				mirror
				punishment
				transformation
				weaver
				universe
				truth
				soul twins
				evolution
				reason
				solitude
				seeker
				gardener
				builder
				teacher
				boat
				tree
				lighting
			Prime Numbers
				37
				41
				43
				47
				53
				59
				61
				67
				71
				73
				79
				83
				89
				97
			Existing Tarot Meanings
				Drastic material change.
				Ambition.
				Obsolete.
				Celebration.
				Calamity.
				Success.
				Competition.
				Obstacles.
				Recovery.
				Strain.
				Helpful friend.
				Material advancement.
				Settling with possessions.
				Material wealth.
				Drastic change of thought.
				Confusion.
				Pondering.
				Self-obsession.
				Destitution.
				Generosity.
				Contemplation.
				Skill.
				Prosperity.
				Wisdom.
				Agreeing friend.
				Intellectual advancement.
				Settling mind.
				Intellectual prominence.
				Drastic change of feelings.
				Bond.
				Festivity.
				Melancholia.
				Despair.
				Happiness.
				Temptation.
				Disgust.
				Gluttony.
				Bliss.
				Comforting friend.
				Emotional advancement.
				Settling emotions.
				Emotional restraint.
				Drastic change of action.
				Crossroads.
				Separation.
				Commemoration.
				Desertion.
				Loss.
				Betrayal.
				Victim.
				Anguish.
				Defeat.
				Allied friend.
				Advancement in action.
				Settling calamity.
				Decisive action.
			17
				Dworkin
					Oberron
						Cymnea
							Benedict
								orange, yellow, brown
								Master Tactician
							Osric and Finndo
								Osric(Dead)
									silver, red
								Finndo(Dead)
									green, gold
								attempted to overthrow their father and were sent to a war and never returned
						Faiella
							Eric
								black, red
								Arrogant but Capable
								Greatest Swordsman
							Corwin
								silver, black
							Deidre
								silver, black
								Most Loved
								Beauty and Compassion
						Clarissa
							Fiona
								green, lavender, purple
								Sorceress
								deft mind and stunning beauty
							Blyes
								red, orange
								Sorceror
								Extrovert, dashing, charming
							Brand
								green
								manic depressive
								meglomaniac sorceror
								faustian
						Lady Moins of Rebma
							Llewella
								green, lavender, gray
								sad existence in self exile
						Harla
						Rilga
							Caine
								black, green
								calculating, realist, manipulator
								naval talent and lifestyle
							Julian
								white, black
								cold, sinister hunter
							Gerard
								blue, gray
								strongest man
								loyal but not smart
						Dybele
							Florimel
								green, gray
								dumb blonde
								pampered
						Kinta
							Coral
						Paulette
							Random
								orange, red, brown
								sneaky rascal
								punk
							Mirelle
								red, yellow
						Lora
							Delwin and Sand
								Delwin
									brown, black
								Sand
									pale tan, dark brown
						Deela
							Dalt
								black, green
								hates the rest of them
			A
				The Abysmal Butcher
				The Aldermarrow
				The Beam Of Hope
				The Bitterblight
				The Celestial Twins
				The Courageous Tactician
				The Daughter of the Desert
				The Death's Defeat
				The Death's Denier
				The Deceptive Beauty
				The Desert Fury
				The Desert's Stone
				The Doomwhisper
				The Dreamhopper
				The Flame Weaver
				The Guardian of the Mountains
				The Hand Of The Wood
				The Harbinger of Justice
				The Heartcarver
				The Keeper Of Glades
				The King of Blades
				The Knight Of The Kingdom
				The Knight Of Valor
				The Leader of Few Words
				The Lightbringer
				The Maniacal Mage
				The Nature's Guardian
				The Nature's Heart
				The Nature's Strength
				The Nature's Voice
				The Plaguegrip
				The Protector of Souls
				The Purger of Sins
				The Queen of Stars
				The Rogue of the Forest
				The Savior of the Sea
				The Seer of Destiny
				The Song Of Dawn
				The Voidbinder
				The Wandering Swordsman
				The Wind Whisperer
				The Wise One
				The Wild Child
				The Whispering Doom
				The Wandering Corsair
				The Wailing Widow
				The Untamed
				The Unruly
				The True Gentleman
				The Fanatical
				The Fallen King
				The Fair Maiden
				The Exalted
				The Devious
				The Demise
				The Righteous
				The Rascal
				The Crafter
				The Burning Light
				The Blood Guard
				The Blood Claw
				The Aggrieved
				The Betrayed
				The Reviled Captain
				The Rising Phoenix
				The Seer of Origins
				The Serpent Charmer
				The Taken Breath
				The Floral Wonder
				The Forgotten Champion
				The Frozen Mother
				The Forsaken Child
				The Insidious
				The Indomitable
				The Far Stalker
				The Kind
				The Languid
				The Malevolent Menace
				The Mind Cager
				The Muddled Magician
				The Precious Pearl
				The Quicksand Recluse
				The Defender
				The Corrupted
				The Corpsemaker
				The Brewmaster
				The Cunning
				The Abomination
				The All Seer
				The Risen Warrior
				The Roamer
				The Serene Promise
				The Sinister Siren
				The Taken Soul
				The eye of hell
				The 1st born
				The bound woman
				The withered lover
				The torn prince
				The angry princess
				The pilgrimess
				The great child
				The dire mother
				The hammer
				The jackal
				The juggernaut
				The broken heart
			seven
				businessman, traitor, amazon, gorgon
				protector, gladiator, nurturer, helicopter
				seductive, muse, artist, abuser
				messiah, destroyer, punisher
				king/queen, parent, tyrant/dictator, slave master
				recluse, mystic, warlock, betrayer
				Inventor, mad scientist
				recluse/mystic, betrayer warlock
				Messiah, destroyer/punisher
				Seducer/Muse, abuser
				Ruler, Tyrant
				Nurturer/protector, jilted/jealous 
				Businessman/Amazon, traitor/gorgon
				Inventor/Artist, mad scientist/Self destrutive
			Arch
				The Businessman
				The Traitor
				The Protector
				The Gladiator
				The Woman's Man
				The Seducer
				The Recluse
				The Warlock
				The Inventor
				The Mad Scientist
				The Fool
				The Derelict
				The Male Messiah
				The Punisher
				The Artist
				The Abuser
				The King
				The Dictator
				Magi
				Mentor
				Best Friend
				Lover
				Joker
				Jester
				Nemesis
				Investigator
				Pessimist
				Psychic
				Shadow
				Lost Soul
				Double
				The Seductive Muse
				The Femme Fatale
				The Amazon
				The Gorgon
				The Father's Daughter
				The Backstabber
				The Nurturer
				The Overcontrolling Mother
				The Matriarch
				The Scorned Woman
				The Mystic
				The Betrayer
				The Female Messiah
				The Destroyer
				The Maiden
				The Troubled Teen
			G
				Supplication
				Deliverance
				Crime pursued by vengeance
				Vengeance taken for kin upon kin
				Pursuit
				Disaster
				Falling prey to cruelty/misfortune
				Revolt
				Daring enterprise
				Abduction
				The enigma
				Obtaining
				Enmity of kin
				Rivalry of kin
				Murderous adultery
				Madness
				Fatal imprudence
				Involuntary crimes of love
				Slaying of kin unrecognized
				Self-sacrifice for an ideal
				Self-sacrifice for kin
				All sacrificed for passion
				Necessity of sacrificing loved ones
				Rivalry of superior vs. inferior
				Adultery
				Crimes of love
				Discovery of the dishonour of a loved one
				Obstacles to love
				An enemy loved
				Ambition
				Conflict with a god
				Mistaken jealousy
				Erroneous judgment
				Remorse
				Recovery of a lost one
				Loss of loved ones
			F
				Apotheosis
				The Ultimate Boon
				Refusal of the Return
				The Magic Flight
				Rescue from Without
				The Crossing of the Return Threshold
				Master of the Two Worlds
				Atonement with the Father/Abyss
				Woman as the Temptress
				The Meeting with the Goddess
				The Road of Trials
				Belly of the Whale
				The Crossing of the First Threshold
				Supernatural Aid
				Refusal of the Call
				The Call to Adventure
			17
				j
					Innocence - carefree ignorance.
					Wizard - surpassing the plausible.
					Secret - hidden influence.
					Benefactor - gentle power.
					Supreme ruler - irresistible power.
					Priest - spiritual authority.
					Love - intense affection.
					Conqueror - success in spite of resistance.
					Hero - a great feat.
					Solitude - isolation.
					Chance - the unpredictable.
					Judge - the rule of law.
					Martyr - sacrifice.
					Grim reaper - coming to an end.
					Patience - time passes.
					Archfiend - nemesis.
					Destruction - failure.
					Distance - the unreachable.
					Soul - longing.
					Ability - triumph.
					Result - final outcome.
					Opportunity - success at hand.
	Storypath Cards
		Path Of Hope
			Case Of Conscience
			Light Heart
			Building The Future
			Valley Of Doom
			Rally
			Deadline Extended
			Good Night's Sleep
			Unexpected Praise
			The Clouds Part
			A Minor Setback
			Lucky Talisman
			Sense Of Despondency
			Childhood Story
			Uplifting Song
			Deep Devotion
			Temptation
			Angel On Your Shoulder
			Whistling Past A Graveyard
			Finding Comfort In The Bottom Of A Bottle
			Heroic Sacrifice
			Demonic Influence
			Broken Taboo
			Between A Rock And A Hard Place
			Overwhelming Odds
			Last Chance
			A Chorus Of Angels
			Yes It's Worth It
			We Have To Try
			The Long Night Begins
			A Dawn Of New Day
			Boost Of Confidence
			Passage From Scripture
			One Perfect Flower
			From The Depths Of Despair
			Overwhelming Sense Of Despair
			Child's Smile
	districts
		far forge
		mead hall
		winter quarter
		long hall
		glass bowl
		heavy rocks
		greater clanking
		the docks
		low house
		maggots end
		grove's end
		bone hook
		clear water
		elm ferry
		middle court
		mead brook
		cotton harbor
		east road
		dairy crossing
		fire arches
		new docks
		moon tower
		egbridge
		sunset ward
		eastway
		heather market
		the song
		light harbor
		grey crossing
		oak docks
		the green
		cabbage end
		four barrows
		oak point
		sunrise town
		northtown
		milik rock
		stupid hedge
		honey square
		east district
		menagerie
		scullion corner
	ttrpg
		ttrpg for social development
		ttrpg from dys training
		roleplaying styles/techniques
		avatars
		breath magic - pneuma
		ozimandius
		theurgy
		heist checklist
			what is the macguffin
			secondary mark(s)
			location physical security
			timeline
			success states
			other people on location
			reason to do heist
			who is the primary mark
			heist location
			location security personnel
			diversion
			fail states
			excape planetsecondary planetpotential complications
			plausible losses
		thaumaturgy -wonder working
		octo-kitty
		ttrpg for problem solving
		different ttrpg styles/types
		critical funble/sucess charts
		data science based faction/opinions based on pc actions and pc and npc interaction
	alchemy
		cinnabar seperates into
			luminous aether
			tenebrific brimstone
			viscous yliaster
		forces
			gravitational
			electromagnetic
			strong nuclear
			weak nuclear
			normal force
				friction
				tension
				elastic
		states of matter
			solid
			liquid
			gas
			plasma
		states of energy
			chemical
			electrical
			mechanical
			thermal
			nuclear
		ammoniun nitrate +water= cold +ions
		salt petre + oil of vitriol (sulfuric acid)= aqua fortis
		spirit ofhartshorn (ammonia)
		matiere obscure
		aether
		brimstone
		lord kelvin 1884 dark matter
		yliaster
		eitr/ichor
		ylem
		aqua fortis-nitric acid
		nitrum flammans-ammonium nitrate
		aqua vitae
		distill
		sulfer
		mercury
		ceration
		purify
		crucible
		multiplication
		projection
		fumes
		compose
		congelation
		take
		retort
		seperate
		sublimate
		calcinate
		crucible
		mani jewels
		cintamani
		pulverize
		eitr
		ichor
		orichalcum
		yliaster
	magic system:true names
		true self
		lost name
		adamic-adam's language
		plato's ideal form
		nomotheist(sp?)
	house names
		touldan
		coulvan
		mortcombe
		moucard
		rutherdows
		crimnal orgs
	links
	occam's razor/principle of parsimony
	dunning kruger effect
	perdidot st station by china mieville
	Orphanage campaign
		Campaign skeleton
			Introduction
		Campaign scene
		Player primer
			Environment setup
				StoryData passage
				Style sheet passage
				Header passage setup
				Footer passage setup
			Starting passage
		Character creator
			Background
				Race
				Station/class
			Basics
				Name
				Concept
				Brief description
					Word cloud
					Key word finder
					Symbol cloud
		World build
			Life
				Flora
				Fauna
				Biomes
			Realms
				Dream
				Ever changing Labyrinth
				Unending wyld
				Deep void
			Magic/technology
				Magic
				Technology
			Civilization
				Cultures
				Ethnicities
				Governements
			History
			Land masses
			Bodies of water
				Oceans
				Seas
				Rivers
					Tributaries
			Deity level
				Powers
				Dominions
				Primordial
		Mechanics build
			Races
			Classes
			Skills
			Feats
			Equipment
			Tech
			Magic
		Campaign plot
		Backstory
			Childhood
				Where were you born?
					Was there anything special or important about the day you were born?
				Who were your parents?
					Are they still alive?
						Father?
						Mother?
					What did your parents do for work?
						How well off financially was your family?
				Did you have any siblings?
					Yes
						How many siblings did you have?
							Brothers?
							Sisters?
							Birth order?
							Did you get along with them?
								Did you like your siblings?
					No
					I had cousins that I was raised with that were practically siblings
					I had a crew of other children that I was raised with that were practically siblings
				Who primarily raised you?
					Was is a happy childhood?
					Where did you live during your childhood?
				What sort of games did you play?
					What was our favorite?
				Were there other children who you interacted with?
				Did you have family who lived close to you?
					Did you know them?
				Did you know what you wanted to be when you grew up?
				Did anything unusual or weird happen when you were a child?
			Adolescence
				Where did you live during your adolescence?
				Did you go to school?
					What was your favorite subject?
				Did you apprentice in a craft?
					Did you enjoy it?
					We’re you good at it?
					Did you go off to live with the your Craft Master?
				Did you learn to be a laborer?
				Did you learn the family business?
				Did you interact with kids your age?
					Did you have any friends?
						Who was your best friend?
				What did your siblings do?
				Are your parents alive through your adolescence?
			Young adulthood
			Recent
		Background
			Originally from
				Starting city
				Somewhere else
			Desire to adventure
			Hidden talent
				Arcane
				Nature
				Skill
				Sense
				Companion
				Item
				Supernatural
			Economic status
				Slave
				Poverty
				Poor
				Middle
				High
				Gentry
				Noble
			Guardian/keeper
				Relative
				Appointed
				Hired
			Childhood mentor/patron
				Relative
				Teacher
				Craftsman
				Neighbor
				Elder/wise person
				Affluent eccentric
			Something everyone notices
				Appearance
					Clothes
					Head
						Face
						Hair
					Upper body
						Torso
						Arms
						Hands
					Lower body
						Legs
						Feet
						Hips
				Mannerism
					Accent
					Phrase
					Ticks
					Movement
			Parents
				Both parents
				One parents
				Neither parents
				Step-parent
			Siblings
				0
				1
				2
				3-4
				More
				Birth order
					Oldest
					Youngest
					Middle
			Upbringing
			Training
				Arts
				Sciences
				Engineering
				Religion
				Craft
				Criminal
				Social
			Bonds
			Flaws
			Ideals
			Personalities
			Race
				Subrace
			Class
				Scholar
					Clerical
						Paladin
						Martyr
					Sciences
						Chemist
							Alchemist
							Apothecary
							Herbalist
					Arcane
						Wizard
						War mage
					Forbidden
						Pacts
							Warlock
							Witch
				Engineer
					Craftsman
				Laborer
					Sailor
				Soldier
					Fighter
					Scout
				Frontiersman
					Hunter
					Beastheart
					Sorcerer
			Questions
				Tell me about your childhood
				Tell me about your adventures
			Locations
				Of infancy
				Of childhood
				Of adolescence
				Of young adulthood
				Starting location
			Ethnicity
				Most common
				Common
				Unusual
				Rare
				Unique
			Education
				Formal
					School
					Clerical
				Apprenticeship
				Laborer
				Self taught

# OSR Ideas

- What is the problem with current DND 5e? Other TTRPG?
- What are the core things that this TTRPG is planning on approaching/facing/mitigating?
- What is the core mechanic to be used?
- What is the core activity or set of activities?
- 5e base
- Simplify
- Neural divergent friendly
- Less fast basic math
- More specialization 
- encourage inventiveness 
- synergy between skills abilities and magic
	- Fewer Scores
		- Physical
		- Mental
		- Social
	- No Value w/ Modifier
		- Just the Modifier
		- Reduces complexity
		- Score is pointless as it is not used except to slow down advancement or add granularity to scores without mechanical granularity
	- Add Descriptor to score as a way of giving mechanical perk for adding narrative description

Fibonacci Sequence
0,1,1,2,3,5,8,13,21,34,55,89

Ability Score Categories
- STRENGTH
- DEXTERITY 
- CONSTITUTION
- INTELLIGENCE
- WISDOM
- CHARISMA

Score vs. Modifier
- 1 = -5
- 2-3 = -4
- 4-5 = -3
- 6-7 = -2
- 8-9 = -1
- 10-11 = 0
- 12-13 = 1
- 14-15 = 2
- 16-17 = 3
- 18-19 = 4
- 20-21 = 5
- 22-23 = 6
- 24-25 = 7
- 26-27 = 8
- 28-29 = 9
- 30 = 10

## Powers
- The Cloud Gatherer
- The Wave Maker
- The Unseen

## Dominions
- The throne of Olympus
- The jailer of Tartarus
- The throne of the sea

## Artifacts
- The Scepter of Jove
- The Bident
- The Trident
- The Helm of Hades

## NPCs
- The Haberdasher
- The Deadman
- The Hierarch

# The DM Screen

## Characters

### Player Characters
- Ally
- August
- Elizabeth
- Elsa
- Lane
- Shanti
- Virginia

### Non-Player Characters

## Campaign

## World

[[WorldBuildingQuestions]]

## Mechanics

### Character Mechanics
- species
- Backgrounds
- classes
- Feats
- Equipment
- Spells

### Game Engine Mechanics
- Checks
	- Advantage/Disadvantage
	- Modifiers
	- Take10/Take20
	- Extended Check
	- Critical Sucess/Failure
- Narrative Override
- Player Character Scarring

# Campaign World One Pager 

Narrative Overview

## Major Things About The World
-
-
-
-
-
- Firearms 

## Main Driver For The Campaign
What is the main thing the characters are tryin to accomplish?

## Important People And Groups

# Character Creation Guide

## Species

## Ethnicities

## Classes

## Equipment

## Spells

What sorts of characters will have the most fun in the campaign?
What books can the players use to build their characters?


# Safety Tools

##What are we talking about? Hard Hats? Safety Goggles? 
Roleplaying Games are about stories that unfold as they are played. 
## Lines And Veils
## Content Warning
## Tone Conversation
## Open Door Policy
## C.A.T.S.
1. Concept: What is the game about? Summary of the setting, characters and the main plot.
2. Aim: What is the goal of the players? To overcome an enemy? Player-versus-player? Play-to-lose?
3. Tone: Which kind of atmosphere do you want to achieve? Creepy, serious, goofy?
4. Subject Matter: Discussing potentially critical topics, ask for your players’ consent.
## X-Card
## Stars And Wishes

# Character Integration

# House Rules

# brain dump
A sense of play

Third person narration of charisma check instead of role playing it out. 

Narrative vs mechanics

Session zero. 
How do you know each other
How did you bond 

Asymmetry of level in pc group 

Pulp spy stories 

Scene Template 

Conflict makes good storytelling 

Discord server???

Discord chat bot rules assistant?

No gatekeeping

Name for NPC 

Fossick VERB 1. Rummage; search.  2. Search for gold in abandoned workings.

Rivière	A necklace of gems that increase in size toward a large central stone, typically consisting of more than one string.

# Improv Thoughts

The importance of "yes and"

Only the DM does "no but"

# Campaign Design Thoughts

- Premise
- Awesome Scene Setters
- Awesome Macguffins
- Awesome Panoramas
- Awesome Side Quests
- Tonal Cues
- DnD canon etheral and astral realm
- 

- What is the purpose of a city in the world? Narratively?

- Ocean of clues

- Alignment is dumb
- Alignment only for extra planar beings

# Character Design Thoughts

- Active Wants
- Drives
- record character scars: enemy crit damage causes scars
- Customize as a goal through feats and perks
- Customize for flavor
- Give a prompt for character design
